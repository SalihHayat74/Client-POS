package com.scalerp.clientpos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
